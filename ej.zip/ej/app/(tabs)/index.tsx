import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Touchable, TouchableOpacity } from 'react-native';

export default function App() {
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [resultado, setResultado] = useState('');
  const [color, setColor] = useState('black');

  const calcularIMC = () => {
    const p = parseFloat(peso);
    const a = parseFloat(altura);

    if (p > 0 && a > 0) {
      const imc = p / (a * a);
      let mensaje = '';
      let colorTexto = 'green';

      if (imc < 18.5) mensaje = 'Peso insuficiente';
      else if (imc < 25) mensaje = 'Normopeso';
      else if (imc < 27) mensaje = 'Sobrepeso grado I';
      else if (imc < 30) mensaje = 'Sobrepeso grado II';
      else if (imc < 35) mensaje = 'Obesidad tipo I';
      else if (imc < 40) mensaje = 'Obesidad tipo II';
      else if (imc < 50) mensaje = 'Obesidad tipo III';
      else mensaje = 'Obesidad tipo IV';

      
      if (imc < 27) colorTexto = 'green';
      else if (imc < 40) colorTexto = 'orange';
      else colorTexto = 'red';

      setResultado(`IMC: ${imc.toFixed(2)} - ${mensaje}`);
      setColor(colorTexto);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Calculadora IMC</Text>
    <View style={styles.calculadora}>
      <Text style ={ styles.texto}>Peso (kg)</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={peso}
        onChangeText={setPeso}
      />

      <Text style ={ styles.texto}>Altura (m)</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={altura}
        onChangeText={setAltura}
      />
      <TouchableOpacity style={styles.boton} onPress={calcularIMC}>
      <Text style ={ styles.textoboton}>Calcular IMC</Text>
      </TouchableOpacity>

      <Text style={{ color: color, marginTop: 20, fontSize: 18 }}>
        {resultado}
      </Text>
      </View>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#34015a'
  },
  calculadora: {
    backgroundColor: '#ffffff',
    padding :20,
    
  },
  texto:{
    color :'#0e00aa',
  },
  boton:{
    backgroundColor: 'transparent',
    borderWidth:1,
    borderColor:'#0e00aa',
    padding: 10,
    borderRadius:4,

  },
  textoboton:{
    textAlign:'center',
     color :'#0e00aa',
     fontSize:16,
  },
  titulo: {
    fontSize: 26,
    textAlign: 'center',
    marginBottom: 20,
    color: '#cf1134'
  },
  input: {
    borderWidth: 1,
    padding: 10,
    marginBottom: 10
  }
});
